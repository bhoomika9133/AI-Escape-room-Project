"""
Version 2 - app.py
==================
THE BLACKWOOD LIGHTHOUSE: THE KEEPER'S LAST SHIFT - Reliable AI Horror Escape Room

Run:  streamlit run version_2/app.py

Flow per player message:
    Streamlit input -> GameEngine.process()  (parse, security filter, validate, update state)
                    -> Narrator.narrate()    (Gemini narration of verified facts, or fallback)
                    -> UI renders the narration + panels read from GameState

The UI never changes game state itself; it only displays GameState.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))

from game_data import (  # noqa: E402
    FATAL_TOLL, GAME_SUBTITLE, GAME_TITLE, INSTRUCTIONS, INTRO_TEXT, ITEMS, MILESTONES, OBJECTS,
    PUZZLES, ROOMS,
)
from game_engine import GameEngine  # noqa: E402
from game_master import Narrator  # noqa: E402
from game_state import GameState  # noqa: E402
from theme import CSS, asset_bytes, svg_data_uri  # noqa: E402

st.set_page_config(page_title="Blackwood Lighthouse - V2", page_icon="🕯️", layout="wide")
st.markdown(CSS, unsafe_allow_html=True)


def load_api_key() -> str | None:
    """Environment variable, project .env file, or Streamlit secrets. Never hardcoded."""
    try:
        from dotenv import load_dotenv

        load_dotenv(Path(__file__).resolve().parent.parent / ".env")
    except ImportError:
        pass
    key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not key:
        try:
            key = st.secrets.get("GEMINI_API_KEY")
        except Exception:
            key = None
    return key


# --------------------------------------------------------------------------
# Session state
# --------------------------------------------------------------------------
def init_state() -> None:
    ss = st.session_state
    ss.setdefault("screen", "home")
    ss.setdefault("game_state", GameState().to_dict())   # authoritative state, stored as JSON-able dict
    ss.setdefault("chat", [])                            # display transcript only
    ss.setdefault("sound", None)
    if "narrator" not in ss:
        ss.narrator = Narrator(load_api_key())


def engine() -> GameEngine:
    """Rebuild the engine around the stored state dict (single source of truth)."""
    return GameEngine(GameState.from_dict(st.session_state.game_state))


def restart() -> None:
    for k in ("screen", "game_state", "chat", "sound"):
        st.session_state.pop(k, None)
    init_state()


def handle_input(text: str) -> None:
    eng = engine()
    result = eng.process(text)
    narration = st.session_state.narrator.narrate(result, eng.state, text)
    st.session_state.game_state = eng.state.to_dict()           # commit validated state
    st.session_state.chat.append({"role": "user", "content": text})
    st.session_state.chat.append({"role": "assistant", "content": narration.text,
                                  "code": result.code, "source": narration.source,
                                  "kind": result.kind})
    st.session_state.sound = None
    if any("bell tolls" in e.lower() for e in result.events):
        st.session_state.sound = "bell.wav"
    elif result.code == "puzzle_solved" and result.action and result.action.target == "radio":
        st.session_state.sound = "radio_static.wav"
    if eng.state.status == "escaped":
        st.session_state.screen = "escaped"
    elif eng.state.status == "lost":
        st.session_state.screen = "lost"


# --------------------------------------------------------------------------
# Rendering helpers
# --------------------------------------------------------------------------
def header() -> None:
    st.markdown(f"<div class='bw-title'>{GAME_TITLE}</div>", unsafe_allow_html=True)
    st.markdown(f"<div class='bw-sub'>{GAME_SUBTITLE}</div>", unsafe_allow_html=True)


def _md(text: str) -> str:
    import markdown

    return markdown.markdown(text)


def panel(title: str, chips: list[str], empty: str, red: bool = False) -> None:
    cls = "bw-chip red" if red else "bw-chip"
    body = "".join(f"<span class='{cls}'>{c}</span>" for c in chips) or \
        f"<span class='bw-muted'>{empty}</span>"
    st.markdown(f"<div class='bw-panel'><h4>{title}</h4>{body}</div>", unsafe_allow_html=True)


def progress_bar(state: GameState) -> None:
    done = [m for m, _ in MILESTONES if (m in state.solved or state.flags.get(m))]
    st.progress(len(done) / len(MILESTONES),
                text=f"Progress: {len(done)} / {len(MILESTONES)} milestones")
    cols = st.columns(len(MILESTONES))
    for col, (mid, label) in zip(cols, MILESTONES):
        mark = "◆" if mid in done else "◇"
        colour = "#c8913f" if mid in done else "#5a5650"
        col.markdown(f"<div style='text-align:center;color:{colour};font-size:.75rem;"
                     f"font-family:Special Elite,monospace'>{mark}<br>{label}</div>",
                     unsafe_allow_html=True)


# --------------------------------------------------------------------------
# Screens
# --------------------------------------------------------------------------
def home_screen() -> None:
    header()
    _, mid, _ = st.columns([1, 3, 1])
    with mid:
        st.markdown(f"<div class='bw-hero'><img src='{svg_data_uri('lighthouse.svg')}'/></div>",
                    unsafe_allow_html=True)
        st.markdown("<p style='text-align:center;margin-top:1rem'>A supernatural psychological "
                    "horror escape room. Gemini tells the story. Python keeps the rules.</p>",
                    unsafe_allow_html=True)
        st.markdown("<p class='bw-muted' style='text-align:center'>Version 2: reliable, "
                    "rule-validated edition</p>", unsafe_allow_html=True)
        if st.button("ENTER THE LIGHTHOUSE", use_container_width=True):
            st.session_state.screen = "intro"
            st.rerun()


def intro_screen() -> None:
    header()
    left, right = st.columns([3, 2])
    with left:
        st.markdown(f"<div class='bw-paper'>{_md(INTRO_TEXT)}</div>", unsafe_allow_html=True)
    with right:
        st.markdown(f"<div class='bw-panel'>{_md(INSTRUCTIONS)}</div>", unsafe_allow_html=True)
        bell = asset_bytes("bell.wav")
        if bell:
            st.caption("The bell (play with sound on):")
            st.audio(bell, format="audio/wav")
        if st.button("START GAME", use_container_width=True):
            st.session_state.screen = "play"
            room = ROOMS[GameState().current_room]
            st.session_state.chat.append({"role": "assistant", "kind": "world",
                                          "content": room["description"] + " What do you do?"})
            st.rerun()


def play_screen() -> None:
    eng = engine()
    s = eng.state
    narrator: Narrator = st.session_state.narrator

    # ---------- sidebar
    with st.sidebar:
        st.markdown(f"<img src='{svg_data_uri('sigil.svg')}' width='70'/>", unsafe_allow_html=True)
        mode = "Gemini narrator" if narrator.gemini_enabled else "Offline narrator"
        cls = "on" if narrator.gemini_enabled else "off"
        st.markdown(f"<span class='bw-badge {cls}'>{mode}</span>", unsafe_allow_html=True)
        st.caption("Python validates every action. Gemini only narrates.")
        if st.button("Restart game"):
            restart()
            st.rerun()
        with st.expander("Authoritative game state (JSON)"):
            view = s.to_dict()
            view["log"] = view["log"][-8:]
            st.json(view)

    # ---------- header & progress
    header()
    tolls = s.bell_tolls
    st.markdown(
        f"<div style='display:flex;justify-content:space-between;align-items:center'>"
        f"<h3 class='bw-flicker' style='margin:0'>{ROOMS[s.current_room]['name']}</h3>"
        f"<span class='bw-chip red'>Bell {tolls} / {FATAL_TOLL}</span>"
        f"<span class='bw-chip'>Actions: {s.turn}</span></div>", unsafe_allow_html=True)
    progress_bar(s)

    main, side = st.columns([5, 2])

    # ---------- right-hand panels
    with side:
        panel("Inventory", [ITEMS[i]["name"] for i in s.inventory], "Your pockets are empty.",
              red=True)
        clues = eng.clue_texts()
        st.markdown("<div class='bw-panel'><h4>Clues</h4>" +
                    ("".join(f"<div class='bw-paper' style='padding:.45rem .6rem;margin:.3rem 0;"
                             f"font-size:.8rem'>{c}</div>" for c in clues)
                     or "<span class='bw-muted'>Nothing discovered yet.</span>") + "</div>",
                    unsafe_allow_html=True)
        panel("Examined", [OBJECTS[o]["name"] if o in OBJECTS else ITEMS[o]["name"]
                           for o in s.examined], "Nothing examined yet.")
        status_chips = [("✔ " if p in s.solved else "✖ ") + PUZZLES[p]["name"] for p in PUZZLES]
        panel("Puzzles", status_chips, "")
        doors = [f"Iron hatch: {s.doors['hatch']}", f"Storm door: {s.doors['storm_door']}"]
        panel("Doors", doors, "")

    # ---------- chat
    with main:
        for turn in st.session_state.chat[-40:]:
            is_user = turn["role"] == "user"
            with st.chat_message("user" if is_user else "assistant",
                                 avatar="🧍" if is_user else "🕯️"):
                st.markdown(turn["content"])
                if not is_user and turn.get("code"):
                    st.caption(f"engine: {turn['code']} · narration: {turn.get('source')}")
        if st.session_state.sound:
            audio = asset_bytes(st.session_state.sound)
            if audio:
                st.audio(audio, format="audio/wav", autoplay=True)
            st.session_state.sound = None

        st.markdown("<span class='bw-muted'>Quick actions</span>", unsafe_allow_html=True)
        actions = eng.quick_actions() + ["look", "inventory", "hint"]
        cols = st.columns(4)
        for i, act in enumerate(actions):
            if cols[i % 4].button(act, key=f"qa_{i}_{act}", use_container_width=True):
                handle_input(act)
                st.rerun()

    text = st.chat_input("What do you do?  (e.g. examine the journal)")
    if text:
        handle_input(text.strip())
        st.rerun()


def escaped_screen() -> None:
    s = GameState.from_dict(st.session_state.game_state)
    header()
    st.markdown("<div class='bw-end'><h1>YOU ESCAPED</h1><p>The storm door opens onto a grey "
                "dawn. A small wet hand squeezes yours once, then is gone. Behind you, the lamp "
                "burns steady. For the first time in over a century, the keeper's shift is "
                "over.</p></div>", unsafe_allow_html=True)
    st.balloons()
    c1, c2, c3 = st.columns(3)
    c1.metric("Actions taken", s.turn)
    c2.metric("Bell tolls survived", f"{s.bell_tolls} / {FATAL_TOLL}")
    c3.metric("Wrong attempts", sum(s.failed_attempts.values()))
    if st.button("PLAY AGAIN", use_container_width=True):
        restart()
        st.rerun()


def lost_screen() -> None:
    header()
    st.markdown("<div class='bw-end'><h1 style='color:#b32a2a !important'>THE THIRTEENTH BELL"
                "</h1><p>The lamp gutters out. Cold hands settle on your shoulders, and a tired "
                "voice says, \"Thank you. Now you keep the light.\"</p></div>",
                unsafe_allow_html=True)
    if st.button("TRY AGAIN", use_container_width=True):
        restart()
        st.rerun()


init_state()
{"home": home_screen, "intro": intro_screen, "play": play_screen, "escaped": escaped_screen,
 "lost": lost_screen}[st.session_state.screen]()
