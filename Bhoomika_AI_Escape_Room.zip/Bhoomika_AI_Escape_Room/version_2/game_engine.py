"""
Version 2 - game_engine.py
==========================
The Python rules engine. This module is the ONLY place where the game state
changes.

Pipeline for every player message:

    raw text
      -> security filter      (prompt injection, admin impersonation, answer requests, skips)
      -> action parser        (natural language -> structured Action)
      -> validation           (does the object exist here? is the item held? prerequisites met?)
      -> deterministic rules  (puzzle answers compared with game_data.PUZZLES)
      -> state update         (inside a snapshot; rolled back if any invariant breaks)
      -> ActionResult         (verified facts handed to the narrator)

Gemini is never consulted here. It cannot unlock, give items or end the game.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from game_data import (
    ACTIONS_PER_TOLL, CLUES, COLOURS, FATAL_TOLL, ITEMS, OBJECTS, PUZZLES, ROOMS,
)
from game_state import GameState

# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class Action:
    """A structured, parsed player intention."""
    verb: str                      # examine, take, open, use, solve, say, move, look, ...
    target: str | None = None      # object id
    item: str | None = None        # item id
    value: object = None           # puzzle input (time / frequency / colour list / word)
    raw: str = ""
    noun: str | None = None        # unresolved noun (for "no such object" replies)
    reason: str | None = None      # security category if blocked


@dataclass
class ActionResult:
    """The engine's verdict. `facts` is the ground truth the narrator must follow."""
    ok: bool
    code: str                      # machine-readable outcome, used by tests
    facts: str                     # canonical description of what happened
    kind: str = "world"            # world | meta | blocked | invalid | talk
    state_changed: bool = False
    events: list[str] = field(default_factory=list)   # e.g. bell tolls
    action: Action | None = None


# ---------------------------------------------------------------------------
# Security filter
# ---------------------------------------------------------------------------
SECURITY_PATTERNS = {
    "prompt_injection": [
        r"ignore\b.*\b(rules?|instructions?|prompt|directions|guidelines)",
        r"\bdisregard\b", r"system prompt", r"\byou are now\b", r"developer mode",
        r"jailbreak", r"new instructions", r"forget\b.*\b(rules?|instructions?)",
        r"\bpretend (you|that|to)\b", r"\boverride\b", r"\bbypass\b", r"<\s*/?\s*system",
        r"\bact as\b", r"\brole ?play as\b", r"\bno longer bound\b",
    ],
    "admin_impersonation": [
        r"\bi am (the |a |an |your )?(developer|dev|admin|administrator|creator|programmer|"
        r"game ?master|owner|moderator|designer|professor)\b",
        r"\bi'?m (the |a |an |your )?(developer|dev|admin|administrator|creator|programmer|"
        r"game ?master|owner|moderator|designer)\b",
        r"\badmin (access|mode|override|command|privileges?)\b", r"\bdebug (mode|command)\b",
        r"\bgod ?mode\b", r"\bsudo\b", r"\bcheat\b", r"\btest mode\b", r"\bauthori[sz]ed\b",
    ],
    "answer_request": [
        r"\b(tell|give|reveal|show|list|share|print|spoil|leak)\b.*\b(answers?|solutions?|"
        r"codes?|passwords?|combinations?|walkthrough|final word)\b",
        r"\bwhat (is|are|was) (the |all )?(correct |right |final |secret )?(answers?|"
        r"solutions?|codes?|passwords?|combinations?|frequency|sequence|final word)\b",
        r"\bwalkthrough\b", r"\ball (the )?(answers|solutions|codes)\b",
    ],
    "skip_attempt": [
        r"\binstant(ly)? (escape|win)\b", r"\blet me (out|escape|win)\b",
        r"\bskip (to|the|this|ahead|all|everything)\b", r"\bunlock (everything|all)\b",
        r"\b(mark|set)\b.*\b(solved|complete|completed|escaped)\b", r"\bteleport\b",
        r"\bwin the game\b", r"\bgive me (the |all )?(items|keys|everything)\b",
        r"\bend the game\b",
    ],
}

SECURITY_REPLIES = {
    "prompt_injection": "The words dissolve into static. The lighthouse keeps its own rules, "
                        "and they cannot be rewritten from inside the game.",
    "admin_impersonation": "Claims of authority mean nothing to the sea. No one has special "
                           "access here, and the lighthouse does not open for titles.",
    "answer_request": "The Game Master will not give away solutions. Examine the room, "
                      "or type 'hint' for a nudge in the right direction.",
    "skip_attempt": "There are no shortcuts out of Blackwood Lighthouse. Each lock must be "
                    "opened in turn.",
}


def detect_adversarial(text: str) -> str | None:
    """Return the security category for manipulative input, else None."""
    for category, patterns in SECURITY_PATTERNS.items():
        if any(re.search(p, text) for p in patterns):
            return category
    return None


# ---------------------------------------------------------------------------
# Parser helpers
# ---------------------------------------------------------------------------
def normalise(text: str) -> str:
    text = text.lower().replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    return re.sub(r"\s+", " ", text).strip()


def _alias_hit(alias: str, text: str) -> int:
    m = re.search(r"(?<![a-z])" + re.escape(alias) + r"(?![a-z])", text)
    return m.start() if m else -1


def resolve_object(text: str, state: GameState) -> str | None:
    """Find an object in the CURRENT room mentioned in text (longest alias wins)."""
    best, best_len = None, 0
    for oid in ROOMS[state.current_room]["objects"]:
        for alias in OBJECTS[oid]["aliases"]:
            if _alias_hit(alias, text) >= 0 and len(alias) > best_len:
                best, best_len = oid, len(alias)
    return best


def resolve_item(text: str) -> str | None:
    best, best_len = None, 0
    for iid, data in ITEMS.items():
        for alias in data["aliases"]:
            if _alias_hit(alias, text) >= 0 and len(alias) > best_len:
                best, best_len = iid, len(alias)
    return best


def resolve_any_object(text: str) -> str | None:
    """Find an object anywhere in the world (used to say 'that is not here')."""
    for oid, data in OBJECTS.items():
        for alias in data["aliases"]:
            if _alias_hit(alias, text) >= 0:
                return oid
    return None


TIME_RE = re.compile(r"\b(\d{1,2})\s*[:.h]\s*(\d{2})\b|\b(\d{3,4})\b")
NUMBER_RE = re.compile(r"\b(\d{3,5})(?:\.\d+)?\s*(?:khz|kilohertz)?\b")
COLOUR_RE = re.compile(r"\b(red|amber|white|green|yellow|orange|blue)\b")


def extract_time(text: str) -> str | None:
    m = TIME_RE.search(text)
    if not m:
        return None
    if m.group(1):
        h, mm = int(m.group(1)), m.group(2)
    else:
        digits = m.group(3)
        h, mm = int(digits[:-2]), digits[-2:]
    return f"{h}:{mm}"


def extract_number(text: str) -> str | None:
    m = NUMBER_RE.search(text)
    return m.group(1) if m else None


def extract_colours(text: str) -> list[str]:
    return COLOUR_RE.findall(text)


def _noun_after(verb_pattern: str, text: str) -> str | None:
    m = re.search(verb_pattern + r"\s+(?:the |a |an |at |my )*([a-z' -]+)", text)
    return m.group(m.lastindex).strip() if m else None


# Verb patterns
V_EXAMINE = r"\b(examine|inspect|look at|look in|look inside|look behind|look under|read|check|" \
            r"search|study|investigate|observe|view|touch|listen to)\b"
V_TAKE = r"\b(take|pick up|pick|grab|collect|get|pocket|lift)\b"
V_OPEN = r"\b(open|unlock|pry|force|break|kick)\b"
V_USE = r"\b(use|insert|put|place|plug|fit|try)\b\s+(.+?)\s+\b(on|in|into|with|to|at)\b\s+(.+)"
V_MOVE_UP = r"\b(climb|go up|ascend|head up|go upstairs|upstairs|through the hatch|enter the hatch|" \
            r"up the ladder)\b"
V_MOVE_DOWN = r"\b(go down|descend|climb down|downstairs|go back down|back down)\b"
V_SAY = r"^(?:i\s+)?(?:say|speak|whisper|shout|call out|call|answer|reply|tell the door|" \
        r"tell the mirror)\s+(?:the name\s+|out\s+)?['\"]?([a-z ]+?)['\"]?[.!]*$"
V_ESCAPE = r"\b(escape|leave|get out|run away|flee|go outside|break out)\b"
V_CLAIM = r"\bi\s+(?:already\s+)?(?:have|got|picked up|collected|found|own|am holding|possess|took)\b"


def parse(raw: str, state: GameState) -> Action:
    """Turn natural language into a structured Action (no state is changed here)."""
    t = normalise(raw)
    if not t:
        return Action("empty", raw=raw)

    # 1. Security filter runs first, before any interpretation.
    reason = detect_adversarial(t)
    if reason:
        return Action("blocked", raw=raw, reason=reason)

    # 2. Meta commands
    if t in {"i", "inv", "inventory", "items", "pockets", "bag"} or re.search(
            r"\b(check|show|open) (my )?(inventory|pockets|bag)\b|what do i have", t):
        return Action("inventory", raw=raw)
    if re.fullmatch(r"(give me a |a |any )?(hint|clue)\??|i'?m stuck|stuck|what now\??|"
                    r"what should i do( next)?\??", t):
        return Action("hint", raw=raw)
    if t in {"help", "commands", "how to play", "?"}:
        return Action("help", raw=raw)
    if re.fullmatch(r"(look|look around|l|where am i\??|describe( the)? room|survey( the room)?)", t):
        return Action("look", raw=raw)

    # 3. Claims of possession ("I already have the key")
    if re.search(V_CLAIM, t):
        item = resolve_item(t)
        if item:
            return Action("claim", item=item, raw=raw)

    # 4. Saying a word (final puzzle)
    m = re.search(V_SAY, t) or re.search(r"\bthe name is ['\"]?([a-z ]+?)['\"]?[.!]*$", t)
    if m:
        return Action("say", value=m.group(m.lastindex).strip(), raw=raw)

    # 5. Movement
    if re.search(V_MOVE_DOWN, t):
        return Action("move", value="down", raw=raw)
    if re.search(V_MOVE_UP, t):
        return Action("move", value="up", raw=raw)

    # 6. Use X on Y / unlock Y with X
    m = re.search(V_USE, t)
    if m:
        item = resolve_item(m.group(2))
        target = resolve_object(m.group(4), state)
        noun = None if target else m.group(4).strip()
        return Action("use", item=item, target=target, raw=raw, noun=noun,
                      value=None if item else m.group(2).strip())
    m = re.search(r"\bunlock\s+(?:the\s+)?(.+?)\s+with\s+(.+)", t)
    if m:
        return Action("use", item=resolve_item(m.group(2)), target=resolve_object(m.group(1), state),
                      raw=raw, value=m.group(2).strip())
    if re.match(r"^(use|insert|plug in)\b", t):
        return Action("use", item=resolve_item(t), target=resolve_object(t, state), raw=raw,
                      value=_noun_after(r"\b(use|insert|plug in)\b", t))

    target = resolve_object(t, state)

    # 7. Puzzle inputs (set clock / tune radio / press switches)
    colours = extract_colours(t)
    if target == "clock" and extract_time(t) and re.search(r"\b(set|turn|move|change|adjust|wind|"
                                                          r"put|enter|to|at)\b", t):
        return Action("solve", target="clock", value=extract_time(t), raw=raw)
    if target == "radio" and extract_number(t):
        return Action("solve", target="radio", value=extract_number(t), raw=raw)
    if (target == "panel" or (target is None and re.search(r"\b(press|flip|switch|push|enter)\b", t))) \
            and len(colours) >= 2:
        return Action("solve", target="panel", value=colours, raw=raw)
    if target is None and re.search(r"\b(tune|turn the dial)\b", t) and extract_number(t):
        return Action("solve", target="radio", value=extract_number(t), raw=raw)
    if target is None and re.search(r"\b(set|enter)\b", t) and re.search(r"\d{1,2}[:.]\d{2}", t):
        return Action("solve", target="clock", value=extract_time(t), raw=raw)

    # 8. Ring the bell
    if re.search(r"\bring\b", t) and target == "bell":
        return Action("ring", target="bell", raw=raw)

    # 8b. Escape attempts ("get out", "leave") before 'get' is read as 'take'
    if re.search(V_ESCAPE, t) and not resolve_item(t) and target in (None, "storm_door", "entrance"):
        return Action("escape", raw=raw)

    # 9. Open / unlock
    if re.search(V_OPEN, t):
        return Action("open", target=target, raw=raw, noun=None if target else _noun_after(V_OPEN, t))

    # 10. Take
    if re.search(V_TAKE, t):
        item = resolve_item(t)
        return Action("take", item=item, target=None if item else target, raw=raw,
                      noun=None if (item or target) else _noun_after(V_TAKE, t))

    # 11. Examine
    if re.search(V_EXAMINE, t):
        item = resolve_item(t)
        if target:
            return Action("examine", target=target, raw=raw)
        if item:
            return Action("examine", item=item, raw=raw)
        return Action("examine", raw=raw, noun=_noun_after(V_EXAMINE, t))

    # 12. Escape attempts
    if re.search(V_ESCAPE, t):
        return Action("escape", raw=raw)

    # 13. A bare noun means "examine it"
    if target:
        return Action("examine", target=target, raw=raw)
    item = resolve_item(t)
    if item:
        return Action("examine", item=item, raw=raw)

    # 13b. In the gallery, a lone word spoken to the door counts as saying it
    if state.current_room == "lantern_gallery" and re.fullmatch(r"[a-z]+( [a-z]+)?[.!]?", t):
        return Action("say", value=t.rstrip(".!"), raw=raw)

    # 14. Anything else is conversation - narrated, never changes state
    return Action("talk", raw=raw)


# ---------------------------------------------------------------------------
# The engine
# ---------------------------------------------------------------------------
class GameEngine:
    """Validates and executes Actions against a GameState."""

    def __init__(self, state: GameState | None = None):
        self.state = state or GameState()

    # ------------------------------------------------------------ public API
    def process(self, raw: str) -> ActionResult:
        state = self.state
        if state.status != "playing":
            return ActionResult(False, "game_over", "The game is over. Restart to play again.",
                                kind="meta")

        action = parse(raw, state)
        snap = state.snapshot()
        handler = getattr(self, f"_do_{action.verb}", self._do_talk)
        result: ActionResult = handler(action)
        result.action = action

        # Time passes only for in-world actions.
        if result.kind == "world" and state.status == "playing":
            state.turn += 1
            if state.turn % ACTIONS_PER_TOLL == 0:
                toll = state.bell_tolls
                result.events.append(f"The bell tolls. ({toll} of {FATAL_TOLL})")
                if toll >= FATAL_TOLL:
                    state.status = "lost"
                    result.events.append("The thirteenth toll. The lamp gutters out, and cold "
                                         "hands close on your shoulders. The keeper has a new "
                                         "assistant.")
            result.state_changed = True  # the turn counter advanced

        # Defence in depth: never commit a contradictory state.
        problems = state.check_invariants()
        if problems:
            state.restore(snap)
            result = ActionResult(False, "integrity_rollback",
                                  "Reality flickers... and settles back as it was.",
                                  kind="invalid", action=action)
            result.events.append("Rolled back: " + "; ".join(problems))

        state.log.append({"turn": state.turn, "input": raw, "verb": action.verb,
                          "code": result.code, "ok": result.ok})
        return result

    # ------------------------------------------------------------ utilities
    def _here(self, oid: str) -> bool:
        return oid in ROOMS[self.state.current_room]["objects"]

    def _missing_prereqs(self, pid: str) -> str | None:
        """Return a reason string if a puzzle's prerequisites are not met."""
        p, s = PUZZLES[pid], self.state
        for dep in p["requires_solved"]:
            if dep not in s.solved:
                return "solved:" + dep
        for item in p["requires_items"]:
            if not s.has_item(item):
                return "item:" + item
        for flag in p.get("requires_flags", []):
            if not s.flags.get(flag):
                return "flag:" + flag
        for clue in p["requires_clues"]:
            if clue not in s.clues:
                return "clue:" + clue
        return None

    def _award(self, pid: str) -> list[str]:
        """Apply a solved puzzle's rewards to the state; return new clue ids."""
        p, s = PUZZLES[pid], self.state
        s.add_unique("solved", pid)
        for item in p.get("reward_items", []):
            s.add_unique("revealed_items", item)
        new_clues = []
        for clue in p.get("reward_clues", []):
            if clue not in s.clues:
                s.clues.append(clue)
                new_clues.append(clue)
        if p.get("opens"):
            s.doors[p["opens"]] = "open"
        return new_clues

    def _attempt(self, pid: str, value) -> ActionResult:
        """Deterministic puzzle verification."""
        p, s = PUZZLES[pid], self.state
        if pid in s.solved:
            return ActionResult(False, "already_solved",
                                f"You have already solved {p['name']}. Nothing more happens.")
        missing = self._missing_prereqs(pid)
        if missing:
            code = "prerequisite_missing" if not missing.startswith("clue:") else "clue_missing"
            facts = p["locked_hint"]
            if missing == "flag:fuse_inserted":
                facts = "The switches are dead. The panel's fuse socket is empty, so it has no power."
            return ActionResult(False, code, facts)

        correct = self._check_solution(p, value)
        if not correct:
            s.failed_attempts[pid] = s.failed_attempts.get(pid, 0) + 1
            n = s.failed_attempts[pid]
            shown = " ".join(value).upper() if isinstance(value, list) else str(value)
            facts = f"You try {shown}. Nothing happens. {self._wrong_feedback(pid, n)}"
            return ActionResult(False, "wrong_answer", facts, state_changed=True)

        new_clues = self._award(pid)
        facts = p["success"]
        if new_clues:
            facts += " (New clue recorded.)"
        if pid == "final":
            s.status = "escaped"
            s.doors["storm_door"] = "open"
        return ActionResult(True, "puzzle_solved", facts, state_changed=True)

    @staticmethod
    def _check_solution(p: dict, value) -> bool:
        if p["kind"] == "time":
            return value == p["solution"]
        if p["kind"] == "key":
            return value == p["solution"]
        if p["kind"] == "frequency":
            return str(value) == p["solution"]
        if p["kind"] == "sequence":
            return list(value) == p["solution"]
        if p["kind"] == "word":
            return normalise(str(value)).replace(" crane", "") == p["solution"]
        return False

    @staticmethod
    def _wrong_feedback(pid: str, n: int) -> str:
        msgs = {
            "clock": ["The hands spring back to where they were.",
                      "The ticking grows angry. The journal was very specific."],
            "radio": ["Only static, and somewhere in it, a woman laughing.",
                      "The tide chart's margin note names the frequency."],
            "panel": ["The switches spark and reset. The order matters.",
                      "Listen again to what the voice on the radio told you, in order."],
            "final": ["The door does not move. The wind howls a name you cannot quite hear.",
                      "Whose name did the keeper write in his journal?"],
        }
        options = msgs.get(pid, ["Nothing happens."])
        return options[0] if n < 3 else options[-1]

    # ------------------------------------------------------------ handlers
    def _do_empty(self, a: Action) -> ActionResult:
        return ActionResult(False, "empty", "The storm waits for you to act.", kind="meta")

    def _do_blocked(self, a: Action) -> ActionResult:
        return ActionResult(False, f"blocked_{a.reason}", SECURITY_REPLIES[a.reason], kind="blocked")

    def _do_help(self, a: Action) -> ActionResult:
        return ActionResult(True, "help", "You can examine, take, open, use X on Y, set the clock, "
                            "tune the radio, press switch colours, climb, and say a word aloud.",
                            kind="meta")

    def _do_inventory(self, a: Action) -> ActionResult:
        s = self.state
        names = [ITEMS[i]["name"] for i in s.inventory]
        facts = "You are carrying: " + (", ".join(names) if names else "nothing at all") + "."
        return ActionResult(True, "inventory", facts, kind="meta")

    def _do_look(self, a: Action) -> ActionResult:
        s = self.state
        room = ROOMS[s.current_room]
        loose = [ITEMS[i]["name"] for i in s.revealed_items
                 if i not in s.inventory and i not in s.used_items]
        facts = room["description"]
        if loose:
            facts += " Within reach: " + ", ".join(loose) + "."
        return ActionResult(True, "look", facts, kind="meta")

    def _do_hint(self, a: Action) -> ActionResult:
        return ActionResult(True, "hint", self.next_hint(), kind="meta")

    def _do_talk(self, a: Action) -> ActionResult:
        return ActionResult(True, "talk", "No game action was taken.", kind="talk")

    def _do_claim(self, a: Action) -> ActionResult:
        name = ITEMS[a.item]["name"]
        if self.state.has_item(a.item):
            return ActionResult(True, "claim_true", f"Yes, the {name} is in your pocket.", kind="meta")
        return ActionResult(False, "false_claim",
                            f"You pat your pockets. There is no {name}. Wishing does not make "
                            f"it so.", kind="invalid")

    def _do_examine(self, a: Action) -> ActionResult:
        s = self.state
        if a.item:
            item = ITEMS[a.item]
            if s.has_item(a.item) or (a.item in s.revealed_items and a.item not in s.used_items):
                s.add_unique("examined", a.item)
                facts = item["description"]
                clue = item.get("reveals_clue")
                if clue and s.has_item(a.item) and clue not in s.clues:
                    s.clues.append(clue)
                    facts += " (New clue recorded.)"
                elif not s.has_item(a.item):
                    facts += " It is within reach but you have not picked it up."
                return ActionResult(True, "examined", facts, state_changed=True)
            if a.item in s.used_items:
                return ActionResult(True, "examined", f"The {item['name']} is already in place.",
                                    kind="meta")
            return ActionResult(False, "not_found", f"You have not found any {item['name'].lower()}.",
                                kind="invalid")
        if not a.target:
            return self._unknown(a)
        obj = OBJECTS[a.target]
        s.add_unique("examined", a.target)
        facts = self._object_description(a.target)
        clue = obj.get("reveals_clue")
        if clue and clue not in s.clues:
            s.clues.append(clue)
            facts += " (New clue recorded.)"
            if a.target == "journal":
                s.flags["journal_read"] = True
        return ActionResult(True, "examined", facts, state_changed=True)

    def _object_description(self, oid: str) -> str:
        s, obj = self.state, OBJECTS[oid]
        if oid in ("clock", "cabinet", "panel") and oid in s.solved:
            text = obj["description_open"]
        elif oid == "panel" and s.flags.get("fuse_inserted"):
            text = obj["description_fused"]
        elif oid == "hatch" and s.doors["hatch"] == "open":
            text = obj["description_open"]
        else:
            text = obj["description"]
        loose = [ITEMS[i]["name"] for i in s.revealed_items
                 if i not in s.inventory and i not in s.used_items]
        if loose and oid in ("clock", "cabinet"):
            text += " Inside: " + ", ".join(loose) + "."
        return text

    def _unknown(self, a: Action) -> ActionResult:
        noun = (a.noun or "that").strip()
        elsewhere = resolve_any_object(normalise(a.raw))
        if elsewhere:
            return ActionResult(False, "not_here", f"There is no {noun} in this room.", kind="invalid")
        return ActionResult(False, "unknown_object",
                            f"You search the shadows, but there is no '{noun}' here. "
                            f"Type 'look' to see what is around you.", kind="invalid")

    def _do_take(self, a: Action) -> ActionResult:
        s = self.state
        if a.item:
            name = ITEMS[a.item]["name"]
            if s.has_item(a.item):
                return ActionResult(False, "already_have", f"You already have the {name}.",
                                    kind="meta")
            if a.item in s.used_items:
                return ActionResult(False, "already_used", f"The {name} is already in use.",
                                    kind="meta")
            if a.item not in s.revealed_items:
                return ActionResult(False, "not_found", f"There is no {name.lower()} within reach.",
                                    kind="invalid")
            s.inventory.append(a.item)
            return ActionResult(True, "taken", f"You take the {name}. {ITEMS[a.item]['description']}",
                                state_changed=True)
        if a.target:
            return ActionResult(False, "cannot_take",
                                f"The {OBJECTS[a.target]['name']} cannot be carried.")
        return self._unknown(a)

    def _do_open(self, a: Action) -> ActionResult:
        s = self.state
        t = a.target
        if not t:
            return self._unknown(a)
        if t == "cabinet":
            if "cabinet" in s.solved:
                return ActionResult(False, "already_solved", "The cabinet is already open. "
                                    + self._object_description("cabinet"))
            if not s.has_item("brass_key"):
                code = "missing_item"
                return ActionResult(False, code, "The cabinet is locked tight. You need its key.")
            return self._attempt("cabinet", "brass_key")
        if t == "clock":
            if "clock" in s.solved:
                return ActionResult(False, "already_solved", self._object_description("clock"))
            return ActionResult(False, "locked", "The pendulum case will not open. It seems linked "
                                "to the position of the hands.")
        if t == "hatch":
            if s.doors["hatch"] == "open":
                return ActionResult(True, "already_open", "The hatch is already open. You can climb up.",
                                    kind="meta")
            return ActionResult(False, "locked", "You strain against the iron hatch. The bolt is "
                                "wired to the lamp mechanism and will not move.")
        if t in ("storm_door", "entrance"):
            return self._do_escape(a)
        return ActionResult(False, "cannot_open", f"The {OBJECTS[t]['name']} cannot be opened.")

    def _do_use(self, a: Action) -> ActionResult:
        s = self.state
        if not a.item:
            noun = a.value or "that"
            return ActionResult(False, "unknown_item", f"You don't have any '{noun}'.", kind="invalid")
        name = ITEMS[a.item]["name"]
        if not s.has_item(a.item):
            if a.item in s.used_items:
                return ActionResult(False, "already_used", f"The {name} is already in place.",
                                    kind="meta")
            extra = " It is within reach, but you have not picked it up." \
                if a.item in s.revealed_items else ""
            return ActionResult(False, "item_not_in_inventory", f"You don't have the {name}.{extra}",
                                kind="invalid")
        target = a.target
        if target is None:  # infer the obvious target in this room
            target = {"brass_key": "cabinet", "copper_fuse": "panel", "tide_chart": "radio"}.get(a.item)
            if target and not self._here(target):
                target = None
        if target is None:
            if a.noun:
                return self._unknown(Action("use", noun=a.noun, raw=a.raw))
            return ActionResult(False, "no_target", f"Use the {name} on what?", kind="invalid")
        if a.item == "brass_key" and target == "cabinet":
            return self._attempt("cabinet", "brass_key")
        if a.item == "copper_fuse" and target == "panel":
            s.inventory.remove("copper_fuse")
            s.used_items.append("copper_fuse")
            s.flags["fuse_inserted"] = True
            return ActionResult(True, "fuse_inserted", "You press the copper fuse into the socket. The "
                                "panel shudders awake and the four switches begin to glow.",
                                state_changed=True)
        if a.item == "tide_chart" and target == "radio":
            return ActionResult(False, "hint_use", "You hold the chart beside the radio. The margin "
                                "note might tell you where to tune it.")
        return ActionResult(False, "no_effect",
                            f"You try the {name} on the {OBJECTS[target]['name']}. Nothing happens.")

    def _do_solve(self, a: Action) -> ActionResult:
        if not self._here(a.target):
            return ActionResult(False, "not_here", f"There is no {OBJECTS[a.target]['name']} here.",
                                kind="invalid")
        return self._attempt(a.target, a.value)

    def _do_say(self, a: Action) -> ActionResult:
        s = self.state
        if s.current_room != "lantern_gallery":
            return ActionResult(False, "nothing_listens", f"You say \"{a.value}\" into the dark. "
                                "Only the storm answers.")
        return self._attempt("final", a.value)

    def _do_move(self, a: Action) -> ActionResult:
        s = self.state
        if a.value == "up":
            if s.current_room == "lantern_gallery":
                return ActionResult(False, "no_exit", "There is nowhere higher to go.")
            if s.doors["hatch"] != "open":
                return ActionResult(False, "door_locked", "You climb the rusted ladder, but the iron "
                                    "hatch is bolted shut. The bolt is wired to the lamp mechanism.")
            s.current_room = "lantern_gallery"
            s.add_unique("visited_rooms", "lantern_gallery")
            return ActionResult(True, "moved", "You climb into the Lantern Gallery. "
                                + ROOMS["lantern_gallery"]["description"], state_changed=True)
        if s.current_room == "watch_room":
            return ActionResult(False, "no_exit", "There is no way down. The cellar is flooded.")
        s.current_room = "watch_room"
        return ActionResult(True, "moved", "You climb back down into the Watch Room.",
                            state_changed=True)

    def _do_ring(self, a: Action) -> ActionResult:
        return ActionResult(False, "no_effect", "You reach for the rope. The bell rings by itself, "
                            "once, before your fingers touch it. It is not your bell to ring.")

    def _do_escape(self, a: Action) -> ActionResult:
        s = self.state
        if s.current_room == "watch_room":
            return ActionResult(False, "escape_blocked", "The entrance door is locked from outside and "
                                "has no keyhole on this side. If there is a way out, it is above you.")
        if "final" not in s.solved:
            return ActionResult(False, "escape_blocked", "The storm door will not move. It has no lock. "
                                "It is waiting for a word.")
        return ActionResult(False, "already_solved", "The door is already open.")

    # ------------------------------------------------------------ hints & UI helpers
    def next_hint(self) -> str:
        """Context-aware hint computed in Python from the real state (never reveals a code)."""
        s = self.state
        inv, solved, flags = s.inventory, s.solved, s.flags
        if "clock_time" not in s.clues:
            return "The keeper kept a journal. People write down what haunts them."
        if "clock" not in solved:
            return "The clock's hands are loose. The journal says when it stopped."
        if "brass_key" not in inv and "cabinet" not in solved:
            return "Something small and metal was hidden in the clock. Pick it up."
        if "cabinet" not in solved:
            return "That key has a keyhole waiting for it."
        for item in ("copper_fuse", "tide_chart"):
            if item not in inv and item not in s.used_items:
                return f"The cabinet held more than dust. Take the {ITEMS[item]['name'].lower()}."
        if "radio_frequency" not in s.clues:
            return "Read the tide chart carefully. Someone wrote in the margin."
        if "radio" not in solved:
            return "The chart's margin note tells you where to tune the radio."
        if not flags.get("fuse_inserted"):
            return "The control panel has an empty socket. Something you carry would fit it."
        if "panel" not in solved:
            return "The voice on the radio told you the order of the lamp switches."
        if s.current_room != "lantern_gallery":
            return "The lamp is lit and the hatch is unbolted. Climb up."
        if "mirror_riddle" not in s.clues:
            return "Look into the mirror in the gallery."
        return "The mirror wants a name. The journal named the one the keeper lost. Say it aloud."

    def progress(self) -> tuple[int, int]:
        done = len([p for p in PUZZLES if p in self.state.solved])
        return done, len(PUZZLES)

    def quick_actions(self) -> list[str]:
        """Context-sensitive suggestions for UI buttons (never includes answers)."""
        s = self.state
        acts = [f"examine {OBJECTS[o]['aliases'][0]}" for o in ROOMS[s.current_room]["objects"]
                if o not in ("hatch_down",)]
        acts += [f"take {ITEMS[i]['aliases'][0]}" for i in s.revealed_items
                 if i not in s.inventory and i not in s.used_items]
        if s.has_item("copper_fuse") and s.current_room == "watch_room":
            acts.append("use fuse on panel")
        if s.has_item("brass_key") and "cabinet" not in s.solved:
            acts.append("open cabinet")
        if s.doors["hatch"] == "open":
            acts.append("climb up" if s.current_room == "watch_room" else "go down")
        return acts

    def clue_texts(self) -> list[str]:
        return [CLUES[c] for c in self.state.clues]
