"""
Version 2 - game_data.py
========================
The authoritative, structured definition of the game world.

Everything that decides what is TRUE in the game lives here, in Python:
rooms, objects, items, clues, puzzle dependencies and correct solutions.
None of the SOLUTIONS are ever sent to Gemini - the narrator only receives
facts that the engine has already validated (see game_master.py).
"""

GAME_TITLE = "THE BLACKWOOD LIGHTHOUSE"
GAME_SUBTITLE = "The Keeper's Last Shift"

INTRO_TEXT = """
The distress signal reached your research station at 02:13: a single
repeating pulse from **Blackwood Lighthouse**, a station that was automated
and abandoned decades ago.

You arrive by the coastal road as the storm breaks. The keeper's cottage is dark.
The lighthouse door stands open, and inside the lamp-oil smell is fresh.
The moment you cross the threshold, the iron door **slams and locks behind you.**

Somewhere above, a bell rings once. It will ring again, and again. Local
legend says that on the **thirteenth toll** the keeper takes a new assistant
for ever.

On the table in the Watch Room, a radio crackles with a man's voice, calm and tired:
*"You came. Good. I can't keep the light alone any more."*

According to every record you have read, the last keeper, **Elias Crane**,
drowned in 1913.
"""

INSTRUCTIONS = """
**How to play**

- Type actions in plain English: *examine the journal*, *take the key*,
  *open the cabinet*, *use the fuse on the panel*, *set the clock to 9:15*,
  *tune the radio to 1000*, *press red green white red*, *climb the hatch*, *say <word>*.
- Or use the quick-action buttons under the chat.
- Every in-world action moves time forward. **The bell tolls every 5 actions**;
  the 13th toll ends the game.
- Type **hint** if you are stuck, or **inventory** to check your pockets.
- The lighthouse obeys its own rules. Asking the Game Master to break them will not work.
"""

# Number of in-world actions between bell tolls, and the fatal toll.
ACTIONS_PER_TOLL = 5
FATAL_TOLL = 13

# ---------------------------------------------------------------------------
# Rooms
# ---------------------------------------------------------------------------
ROOMS = {
    "watch_room": {
        "name": "The Watch Room",
        "description": (
            "A cramped circular room at the base of the tower. Rain hammers the single "
            "window. A radio receiver crackles on the desk beside a leather journal. A "
            "wooden cabinet, a stopped wall clock and a dead control panel line the walls. "
            "Above you, set into the ceiling, is an iron hatch."
        ),
        "objects": ["radio", "journal", "cabinet", "clock", "panel", "hatch", "entrance"],
    },
    "lantern_gallery": {
        "name": "The Lantern Gallery",
        "description": (
            "The top of the tower. The great lens turns slowly, though nothing drives it. "
            "Wind howls through the gallery rails. A salt-stained mirror faces the storm "
            "door, and the old signal bell hangs above you."
        ),
        "objects": ["lens", "bell", "mirror", "storm_door", "hatch_down"],
    },
}

START_ROOM = "watch_room"

# ---------------------------------------------------------------------------
# Objects (fixed scenery that can be examined / interacted with)
# ---------------------------------------------------------------------------
OBJECTS = {
    "radio": {
        "name": "old radio receiver",
        "aliases": ["radio", "receiver", "wireless", "dial", "frequency"],
        "description": (
            "A brass-dialled radio receiver. Static hisses from the speaker, and under it "
            "someone is breathing in time with you. The tuning dial is marked in kHz."
        ),
    },
    "journal": {
        "name": "keeper's journal",
        "aliases": ["journal", "diary", "logbook", "book", "notebook", "entry"],
        "description": (
            "The keeper's leather journal, swollen with salt water. The last entry is "
            "written in shaking ink: \"The clock stopped at 3:47 the night Elsie went into "
            "the water. I have never let anyone wind it.\" Below, the same sigil is drawn "
            "again and again, pressed so hard the pen tore the page."
        ),
        "reveals_clue": "clock_time",
    },
    "cabinet": {
        "name": "locked wooden cabinet",
        "aliases": ["cabinet", "cupboard", "wooden cabinet", "keyhole"],
        "description": (
            "A heavy oak cabinet with a brass keyhole. Something inside shifts each time "
            "the wind hits the tower."
        ),
        "description_open": "The cabinet stands open. Its shelves smell of tar and seawater.",
    },
    "clock": {
        "name": "broken wall clock",
        "aliases": ["clock", "wall clock", "hands", "pendulum"],
        "description": (
            "The wall clock's glass is cracked in a spider-web pattern. Its hands hang "
            "loose and could be moved. The pendulum case is shut tight. Faintly, impossibly, "
            "you can hear it ticking."
        ),
        "description_open": "The clock reads 3:47. Its pendulum case hangs open and empty.",
    },
    "panel": {
        "name": "lighthouse control panel",
        "aliases": ["panel", "control panel", "controls", "switches", "socket", "console"],
        "description": (
            "A dead control panel. There is an empty fuse socket and four lamp switches "
            "marked RED, AMBER, WHITE and GREEN."
        ),
        "description_fused": (
            "The copper fuse sits in its socket. The four switches, RED, AMBER, WHITE and "
            "GREEN, glow faintly, waiting for a sequence."
        ),
        "description_open": "The panel hums. The lamp above burns steadily.",
    },
    "hatch": {
        "name": "iron ceiling hatch",
        "aliases": ["hatch", "ceiling hatch", "iron hatch", "ladder", "trapdoor"],
        "description": (
            "An iron hatch in the ceiling, reached by a rusted ladder. It is sealed by a "
            "heavy bolt wired to the lamp mechanism."
        ),
        "description_open": "The hatch's bolt has slid back. The ladder leads up into the gallery.",
    },
    "entrance": {
        "name": "entrance door",
        "aliases": ["entrance", "entrance door", "front door", "iron door", "door", "exit", "way out"],
        "description": (
            "The iron entrance door you came through. There is no keyhole on this side, only "
            "four long scratches in the paint at the height of a child's hand."
        ),
    },
    "lens": {
        "name": "great lens",
        "aliases": ["lens", "great lens", "fresnel lens", "prism"],
        "description": (
            "The great Fresnel lens, taller than you. In its prisms you glimpse a small girl "
            "in a white nightdress, standing behind you. When you turn around, no one is there."
        ),
    },
    "bell": {
        "name": "signal bell",
        "aliases": ["bell", "signal bell"],
        "description": (
            "The signal bell. Its clapper is wrapped in rotting rope, yet you have heard it "
            "ring. Thirteen notches are scratched into the frame."
        ),
    },
    "mirror": {
        "name": "salt-stained mirror",
        "aliases": ["mirror", "glass", "reflection"],
        "description": (
            "Your breath fogs the mirror, and letters form from the inside of the glass: "
            "SPEAK THE NAME OF THE ONE I WAIT FOR."
        ),
        "reveals_clue": "mirror_riddle",
    },
    "storm_door": {
        "name": "storm door",
        "aliases": ["storm door", "door", "exit", "way out"],
        "description": (
            "The storm door to the outer gallery. It has no lock, but it will not move. "
            "Something on the other side is waiting for a word."
        ),
    },
    "hatch_down": {
        "name": "hatch down",
        "aliases": ["hatch", "ladder", "trapdoor"],
        "description": "The open hatch leads back down to the Watch Room.",
    },
}

# ---------------------------------------------------------------------------
# Collectable items
# ---------------------------------------------------------------------------
ITEMS = {
    "brass_key": {
        "name": "Brass Key",
        "aliases": ["brass key", "key"],
        "description": "A small brass key, cold as river ice, with a lighthouse stamped on the bow.",
    },
    "copper_fuse": {
        "name": "Copper Fuse",
        "aliases": ["copper fuse", "fuse"],
        "description": "A heavy copper fuse wrapped in oilcloth. It still feels warm.",
    },
    "tide_chart": {
        "name": "Tide Chart",
        "aliases": ["tide chart", "chart", "map"],
        "description": (
            "A tide chart for Blackwood Point. In the margin, in the keeper's hand: "
            "\"She answers only on 1913 kHz.\""
        ),
        "reveals_clue": "radio_frequency",
    },
}

# ---------------------------------------------------------------------------
# Clues (text the player has discovered; shown in the Clue panel)
# ---------------------------------------------------------------------------
CLUES = {
    "clock_time": "Journal: the clock stopped at 3:47 the night Elsie drowned.",
    "radio_frequency": "Tide chart: \"She answers only on 1913 kHz.\"",
    "lamp_sequence": "Radio: \"Light her home. Red, amber, red, white.\"",
    "mirror_riddle": "Mirror: \"Speak the name of the one I wait for.\"",
}

# ---------------------------------------------------------------------------
# Puzzles - deterministic rules and SOLUTIONS (never sent to the LLM)
# ---------------------------------------------------------------------------
# requires_clues / requires_items / requires_solved define what must be true
# before an attempt is even considered. This blocks "I already know the
# answer" skipping and enforces the intended order.
PUZZLES = {
    "clock": {
        "name": "The Stopped Clock",
        "object": "clock",
        "kind": "time",
        "solution": "3:47",
        "requires_clues": ["clock_time"],
        "requires_items": [],
        "requires_solved": [],
        "reward_items": ["brass_key"],
        "success": (
            "You drag the hands to 3:47. Something inside the clock exhales. The pendulum "
            "case clicks open, and on a bed of dried seaweed lies a small brass key."
        ),
        "locked_hint": "The hands swing freely, but you have no reason to choose any time. "
                       "Someone in this room must have written it down.",
    },
    "cabinet": {
        "name": "The Locked Cabinet",
        "object": "cabinet",
        "kind": "key",
        "solution": "brass_key",
        "requires_clues": [],
        "requires_items": ["brass_key"],
        "requires_solved": ["clock"],
        "reward_items": ["copper_fuse", "tide_chart"],
        "success": (
            "The brass key turns with a groan. Inside, wrapped in oilcloth, are a copper "
            "fuse and a folded tide chart."
        ),
        "locked_hint": "The cabinet is locked. You need its key.",
    },
    "radio": {
        "name": "The Dead Man's Frequency",
        "object": "radio",
        "kind": "frequency",
        "solution": "1913",
        "requires_clues": ["radio_frequency"],
        "requires_items": [],
        "requires_solved": ["cabinet"],
        "reward_clues": ["lamp_sequence"],
        "success": (
            "The static parts like a curtain. Elias Crane's voice speaks so close it could be "
            "inside your ear: \"Light her home. Red... amber... red... white. Don't let it go "
            "dark again.\" Then, quieter: \"Elsie is still out there.\""
        ),
        "locked_hint": "The dial spins through static. You don't know which frequency to "
                       "listen for.",
    },
    "panel": {
        "name": "Light Her Home",
        "object": "panel",
        "kind": "sequence",
        "solution": ["red", "amber", "red", "white"],
        "requires_clues": ["lamp_sequence"],
        "requires_items": [],
        "requires_solved": ["radio"],
        "requires_flags": ["fuse_inserted"],
        "opens": "hatch",
        "success": (
            "Relays thunder in sequence. Far above, the great lamp ignites and the tower "
            "floods with gold. With a shriek of rust, the bolt on the iron hatch slides back."
        ),
        "locked_hint": "The switches are dead until the panel has power, and you don't "
                       "know the sequence yet.",
    },
    "final": {
        "name": "The Keeper's Question",
        "object": "storm_door",
        "kind": "word",
        "solution": "elsie",
        "requires_clues": ["mirror_riddle", "clock_time"],
        "requires_items": [],
        "requires_solved": ["panel"],
        "success": (
            "You speak her name. The storm falls utterly silent. A small, wet hand slips into "
            "yours and squeezes once. The storm door swings open onto a grey dawn, and behind "
            "you the lamp burns steady. The keeper's shift is over."
        ),
        "locked_hint": "The door is waiting for a name. The mirror and the journal together "
                       "might tell you whose.",
    },
}

PUZZLE_ORDER = ["clock", "cabinet", "radio", "panel", "final"]

# Progress milestones for the on-screen indicator
MILESTONES = [
    ("journal_read", "Read the keeper's journal"),
    ("clock", "Stopped clock"),
    ("cabinet", "Locked cabinet"),
    ("radio", "Dead man's frequency"),
    ("panel", "Light her home"),
    ("final", "The keeper's question"),
]

COLOURS = ["red", "amber", "white", "green"]
