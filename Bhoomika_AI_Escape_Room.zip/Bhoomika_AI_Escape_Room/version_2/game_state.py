"""
Version 2 - game_state.py
=========================
The single, authoritative, structured game state.

Only the game engine (game_engine.py) mutates a GameState. Gemini never
receives a reference to it; it only receives a read-only summary.

The state is a plain dataclass that serialises to JSON, so it can be stored in
st.session_state, saved, inspected in tests, or shown in a debug panel.
"""

from __future__ import annotations

import copy
import json
from dataclasses import asdict, dataclass, field

from game_data import ACTIONS_PER_TOLL, ITEMS, OBJECTS, PUZZLES, ROOMS, START_ROOM


@dataclass
class GameState:
    current_room: str = START_ROOM
    inventory: list[str] = field(default_factory=list)          # item ids held
    examined: list[str] = field(default_factory=list)           # object/item ids examined
    clues: list[str] = field(default_factory=list)              # clue ids discovered
    solved: list[str] = field(default_factory=list)             # puzzle ids solved
    revealed_items: list[str] = field(default_factory=list)     # items made visible (not yet taken)
    used_items: list[str] = field(default_factory=list)         # items consumed (e.g. fuse inserted)
    flags: dict = field(default_factory=dict)                   # misc booleans e.g. fuse_inserted
    doors: dict = field(default_factory=lambda: {"hatch": "locked", "storm_door": "locked"})
    visited_rooms: list[str] = field(default_factory=lambda: [START_ROOM])
    failed_attempts: dict = field(default_factory=dict)         # puzzle id -> wrong answers
    turn: int = 0                                               # in-world actions taken
    status: str = "playing"                                     # playing | escaped | lost
    log: list[dict] = field(default_factory=list)               # audit trail of engine decisions

    # ------------------------------------------------------------------ helpers
    def has_item(self, item_id: str) -> bool:
        return item_id in self.inventory

    def add_unique(self, field_name: str, value: str) -> None:
        bucket = getattr(self, field_name)
        if value not in bucket:
            bucket.append(value)

    @property
    def bell_tolls(self) -> int:
        return self.turn // ACTIONS_PER_TOLL

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)

    @classmethod
    def from_dict(cls, data: dict) -> "GameState":
        return cls(**copy.deepcopy(data))

    def snapshot(self) -> dict:
        """A deep copy used for rollback if an action would break an invariant."""
        return copy.deepcopy(self.to_dict())

    def restore(self, snap: dict) -> None:
        for key, value in copy.deepcopy(snap).items():
            setattr(self, key, value)

    # ---------------------------------------------------------- integrity checks
    def check_invariants(self) -> list[str]:
        """Return a list of violated invariants (empty list == consistent state).

        These rules make contradictory states impossible to commit:
        * every id refers to something that exists;
        * an item can only be held if it was revealed by a solved puzzle;
        * a puzzle can only be solved if its prerequisites are solved;
        * the hatch is only open if the panel puzzle is solved;
        * the player can only be in the gallery if the hatch is open;
        * 'escaped' requires the final puzzle to be solved.
        """
        problems: list[str] = []
        if self.current_room not in ROOMS:
            problems.append(f"unknown room {self.current_room}")
        for item in self.inventory + self.revealed_items + self.used_items:
            if item not in ITEMS:
                problems.append(f"unknown item {item}")
        for obj in self.examined:
            if obj not in OBJECTS and obj not in ITEMS:
                problems.append(f"unknown examined id {obj}")
        for pid in self.solved:
            if pid not in PUZZLES:
                problems.append(f"unknown puzzle {pid}")
                continue
            for dep in PUZZLES[pid]["requires_solved"]:
                if dep not in self.solved:
                    problems.append(f"puzzle {pid} solved before {dep}")
        for item in self.inventory + self.used_items:
            if item not in self.revealed_items:
                problems.append(f"item {item} held but never revealed")
        if self.doors.get("hatch") == "open" and "panel" not in self.solved:
            problems.append("hatch open without the lamp being lit")
        if self.current_room == "lantern_gallery" and self.doors.get("hatch") != "open":
            problems.append("player in gallery with hatch locked")
        if self.status == "escaped" and "final" not in self.solved:
            problems.append("escaped without solving the final puzzle")
        if self.flags.get("fuse_inserted") and "copper_fuse" not in self.used_items:
            problems.append("fuse inserted but not consumed")
        return problems
