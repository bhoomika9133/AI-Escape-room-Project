"""
Shared pytest helpers.

Version 1 and Version 2 deliberately use the same module names (game_data,
game_master, ...) so each app runs independently. To test both in one pytest
session, `load_version` clears those names from sys.modules and imports them
fresh from the requested folder.
"""

import importlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SHARED_NAMES = ["game_data", "game_master", "game_engine", "game_state", "theme"]


def load_version(version: str, *names: str):
    folder = str(ROOT / version)
    for n in SHARED_NAMES:
        sys.modules.pop(n, None)
    sys.path.insert(0, folder)
    try:
        modules = [importlib.import_module(n) for n in names]
    finally:
        sys.path.remove(folder)
    return modules if len(modules) > 1 else modules[0]


def purge_shared_modules() -> None:
    """Forget cached game modules before running an app through AppTest."""
    for n in SHARED_NAMES:
        sys.modules.pop(n, None)
