# Running in Google Colab (optional)

Streamlit needs a public tunnel inside Colab. In a Colab cell:

```python
!unzip -q Bhoomika_AI_Escape_Room.zip
%cd Bhoomika_AI_Escape_Room
!pip install -q -r requirements.txt
import os
from google.colab import userdata
os.environ["GEMINI_API_KEY"] = userdata.get("GEMINI_API_KEY")  # store the key in Colab "Secrets" (key icon)
!python -m pytest tests -q
!streamlit run version_2/app.py --server.port 8501 &>/content/log.txt &
!npx --yes localtunnel --port 8501
```

Open the printed URL. Without a key, both games run in offline mode.
