"""
generate_assets.py
------------------
Generates every original visual and audio asset used by both versions of
"The Blackwood Lighthouse: The Keeper's Last Shift".

Nothing here is downloaded or copied: the lighthouse illustration is hand-written
SVG and the sounds are synthesised with NumPy. Run it from the project root:

    python tools/generate_assets.py

It writes identical copies into version_1/assets and version_2/assets so that
each version runs independently.
"""

from __future__ import annotations

import wave
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
TARGETS = [ROOT / "version_1" / "assets", ROOT / "version_2" / "assets"]
RATE = 22050  # sample rate (Hz) - small files, adequate quality

# --------------------------------------------------------------------------
# 1. Lighthouse illustration (original SVG)
# --------------------------------------------------------------------------
LIGHTHOUSE_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 420" role="img"
     aria-label="A lighthouse on a cliff in a storm">
  <defs>
    <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#05060a"/>
      <stop offset="0.6" stop-color="#151821"/>
      <stop offset="1" stop-color="#22202a"/>
    </linearGradient>
    <linearGradient id="sea" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#121821"/>
      <stop offset="1" stop-color="#05070a"/>
    </linearGradient>
    <radialGradient id="glow" cx="0.5" cy="0.5" r="0.5">
      <stop offset="0" stop-color="#ffcf7a" stop-opacity="0.95"/>
      <stop offset="0.4" stop-color="#d98b2b" stop-opacity="0.45"/>
      <stop offset="1" stop-color="#8a1c1c" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="beam" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0" stop-color="#ffd58a" stop-opacity="0.55"/>
      <stop offset="1" stop-color="#ffd58a" stop-opacity="0"/>
    </linearGradient>
  </defs>
  <rect width="800" height="420" fill="url(#sky)"/>
  <!-- storm clouds -->
  <g fill="#2a2d38" opacity="0.85">
    <ellipse cx="120" cy="60" rx="170" ry="38"/>
    <ellipse cx="380" cy="40" rx="210" ry="34"/>
    <ellipse cx="660" cy="70" rx="190" ry="40"/>
  </g>
  <!-- lightning -->
  <polyline points="640,40 615,110 640,108 605,190" fill="none" stroke="#c9c3b5"
            stroke-width="3" opacity="0.55"/>
  <!-- rain -->
  <g stroke="#6d7385" stroke-width="1" opacity="0.35">
    <line x1="40" y1="0" x2="20" y2="420"/><line x1="140" y1="0" x2="120" y2="420"/>
    <line x1="260" y1="0" x2="240" y2="420"/><line x1="470" y1="0" x2="450" y2="420"/>
    <line x1="560" y1="0" x2="540" y2="420"/><line x1="720" y1="0" x2="700" y2="420"/>
  </g>
  <!-- beam -->
  <polygon points="470,138 800,80 800,200" fill="url(#beam)"/>
  <!-- sea -->
  <rect y="320" width="800" height="100" fill="url(#sea)"/>
  <path d="M0 330 Q 60 315 120 330 T 240 330 T 360 330 T 480 330 T 600 330 T 720 330 T 840 330"
        fill="none" stroke="#3b4556" stroke-width="2"/>
  <!-- cliff -->
  <path d="M300 420 L330 300 L380 280 L520 285 L560 310 L600 420 Z" fill="#0c0d10"/>
  <!-- tower -->
  <polygon points="420,282 480,282 470,150 430,150" fill="#d9d2c3"/>
  <polygon points="425,250 475,250 473,232 427,232" fill="#8a1c1c"/>
  <polygon points="428,205 472,205 471,188 429,188" fill="#8a1c1c"/>
  <rect x="440" y="215" width="8" height="12" fill="#1a1a1a"/>
  <!-- gallery + lantern -->
  <rect x="422" y="142" width="56" height="8" fill="#2b2b2b"/>
  <rect x="434" y="120" width="32" height="22" fill="#3a3326"/>
  <circle cx="450" cy="131" r="38" fill="url(#glow)"/>
  <rect x="438" y="124" width="24" height="14" fill="#ffd58a"/>
  <polygon points="430,120 470,120 450,104" fill="#1c1c1c"/>
  <!-- door -->
  <rect x="442" y="262" width="16" height="20" fill="#2a1a12"/>
</svg>
"""

# Small decorative sigil drawn in the margin of the keeper's journal.
SIGIL_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" role="img"
     aria-label="Keeper's sigil">
  <circle cx="60" cy="60" r="52" fill="none" stroke="#b5894a" stroke-width="2"/>
  <circle cx="60" cy="60" r="38" fill="none" stroke="#8a1c1c" stroke-width="1.5"
          stroke-dasharray="4 3"/>
  <polygon points="60,18 70,60 60,102 50,60" fill="none" stroke="#b5894a" stroke-width="2"/>
  <line x1="18" y1="60" x2="102" y2="60" stroke="#b5894a" stroke-width="1.5"/>
  <text x="60" y="66" text-anchor="middle" font-family="Georgia" font-size="16"
        fill="#d9c9a3">XIII</text>
</svg>
"""


def _write_wav(path: Path, samples: np.ndarray) -> None:
    """Write a mono 16-bit WAV file from float samples in [-1, 1]."""
    pcm = np.int16(np.clip(samples, -1, 1) * 32767 * 0.8)
    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(RATE)
        wf.writeframes(pcm.tobytes())


def bell_toll(seconds: float = 4.0) -> np.ndarray:
    """A deep, slightly detuned bell built from inharmonic partials."""
    t = np.linspace(0, seconds, int(RATE * seconds), endpoint=False)
    base = 110.0
    partials = [(0.5, 1.0), (1.0, 0.8), (1.19, 0.5), (1.56, 0.35), (2.0, 0.3), (2.74, 0.2)]
    sig = np.zeros_like(t)
    for ratio, amp in partials:
        decay = np.exp(-t * (0.9 + ratio * 0.6))
        sig += amp * decay * np.sin(2 * np.pi * base * ratio * t)
    return sig / np.max(np.abs(sig))


def radio_static(seconds: float = 3.0) -> np.ndarray:
    """Band-limited static with a faint, wavering carrier tone."""
    rng = np.random.default_rng(1913)
    n = int(RATE * seconds)
    noise = rng.normal(0, 1, n)
    kernel = np.ones(6) / 6  # crude low-pass
    noise = np.convolve(noise, kernel, mode="same")
    t = np.arange(n) / RATE
    carrier = 0.25 * np.sin(2 * np.pi * (440 + 30 * np.sin(2 * np.pi * 0.7 * t)) * t)
    flutter = 0.6 + 0.4 * np.sin(2 * np.pi * 3.1 * t)
    sig = (0.5 * noise + carrier) * flutter
    return sig / np.max(np.abs(sig))


def main() -> None:
    bell = bell_toll()
    static = radio_static()
    for folder in TARGETS:
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "lighthouse.svg").write_text(LIGHTHOUSE_SVG, encoding="utf-8")
        (folder / "sigil.svg").write_text(SIGIL_SVG, encoding="utf-8")
        _write_wav(folder / "bell.wav", bell)
        _write_wav(folder / "radio_static.wav", static)
        print(f"Assets written to {folder}")


if __name__ == "__main__":
    main()
