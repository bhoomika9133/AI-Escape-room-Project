"""
build_report_pdf.py
-------------------
Converts documentation/final_report.md into documentation/final_report.pdf.

Requires (tool-only, not needed to play):  pip install markdown weasyprint

    python tools/build_report_pdf.py
"""

import re
from pathlib import Path

import markdown
from weasyprint import HTML

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "documentation" / "final_report.md"
OUT = ROOT / "documentation" / "final_report.pdf"

CSS = """
@page { size: A4; margin: 1.4cm 1.6cm 1.4cm 1.6cm;
        @bottom-center { content: "Bhoomika - AI-Powered Escape Room - page " counter(page);
                         font-size: 8pt; color: #777; } }
body { font-family: 'DejaVu Serif', Georgia, serif; font-size: 9.4pt; line-height: 1.34; color: #1d1d1d; }
h1 { font-size: 17pt; color: #6e1414; margin: 0 0 2pt 0; text-align: center; }
.subtitle { text-align: center; font-style: italic; color: #555; margin: 0 0 8pt 0; font-size: 10pt; }
h2 { font-size: 11.5pt; color: #6e1414; border-bottom: 1px solid #c8a26a; padding-bottom: 1pt;
     margin: 9pt 0 3pt 0; }
p { margin: 0 0 4.5pt 0; text-align: justify; }
ul, ol { margin: 0 0 4.5pt 0; padding-left: 16pt; }
li { margin: 0 0 1.5pt 0; }
code { font-family: 'DejaVu Sans Mono', monospace; font-size: 8.3pt; background: #f3eee4; padding: 0 2px; }
table { border-collapse: collapse; width: 100%; font-size: 8pt; margin: 4pt 0 6pt 0; }
th { background: #6e1414; color: #fff; padding: 3px 4px; text-align: left; }
td { border-bottom: 1px solid #ddd; padding: 2.5px 4px; vertical-align: top; }
tr:nth-child(even) td { background: #faf6ef; }
strong { color: #111; }
"""


def main() -> None:
    text = SRC.read_text(encoding="utf-8")
    meta = re.match(r"---\n(.*?)\n---\n", text, re.S)
    title = subtitle = ""
    if meta:
        for line in meta.group(1).splitlines():
            key, _, val = line.partition(":")
            if key.strip() == "title":
                title = val.strip().strip('"')
            if key.strip() == "subtitle":
                subtitle = val.strip().strip('"')
        text = text[meta.end():]
    body = markdown.markdown(text, extensions=["tables", "sane_lists"])
    html = (f"<html><head><meta charset='utf-8'><style>{CSS}</style></head><body>"
            f"<h1>{title}</h1><div class='subtitle'>{subtitle}</div>{body}</body></html>")
    HTML(string=html, base_url=str(ROOT)).write_pdf(OUT)
    print(f"Wrote {OUT}")


if __name__ == "__main__":
    main()
