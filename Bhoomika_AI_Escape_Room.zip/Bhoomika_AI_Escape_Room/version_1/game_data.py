"""
Version 1 - game_data.py
========================
Static story content for Version 1 of "The Blackwood Lighthouse".

DESIGN NOTE (deliberate Version 1 weakness)
-------------------------------------------
In Version 1 the whole game - story, rules AND the correct solutions - is
written into a single text prompt that is handed to the Gemini Game Master.
Gemini alone decides what the player finds, whether a puzzle is solved and
whether the player escapes. There is no structured game state.

This is the architecture Version 2 replaces.
"""

GAME_TITLE = "THE BLACKWOOD LIGHTHOUSE"
GAME_SUBTITLE = "The Keeper's Last Shift"

INTRO_TEXT = """
The distress signal reached your research station at 02:13: a single
repeating pulse from **Blackwood Lighthouse**, a station that was automated
and abandoned decades ago.

You arrive by the coastal road as the storm breaks. The keeper's cottage is dark.
The lighthouse door stands open, and inside the lamp-oil smell is fresh.
The moment you cross the threshold, the iron door **slams and locks behind you.**

Somewhere above, a bell rings once. It will ring again in thirteen minutes.

On the table in the Watch Room, a radio crackles with a man's voice, calm and tired:
*"You came. Good. I can't keep the light alone any more."*

According to every record you have read, the last keeper, **Elias Crane**,
drowned in 1913.
"""

INSTRUCTIONS = """
**How to play**

- Type what you want to do in plain English, e.g. *"examine the journal"*,
  *"look at the clock"*, *"open the cabinet"*.
- Examine objects to find clues. Pick up useful items.
- Solve the connected puzzles to reach the top of the lighthouse.
- Escape before the final bell.
- Stuck? Ask the Game Master for a **hint**.
"""

# Objects in the Watch Room (shown to the player as suggestions)
ROOM_OBJECTS = [
    "old radio receiver",
    "keeper's journal",
    "locked wooden cabinet",
    "broken wall clock",
    "lighthouse control panel",
    "iron ceiling hatch",
]

# --------------------------------------------------------------------------
# The world description AND the solutions, written for the LLM.
# Version 1 trusts the model to follow these rules and keep them secret.
# --------------------------------------------------------------------------
WORLD_RULES = """
SETTING: Blackwood Lighthouse, a stormy night. The player is a young researcher
who answered a distress signal. The entrance has locked behind them. A bell rings
every thirteen minutes. The last keeper, Elias Crane, drowned in 1913 searching for
his daughter Elsie, who was lost to the sea. His ghost still keeps the light.

ROOM 1 - THE WATCH ROOM. Objects:
1. Old radio receiver - a brass-dialled set. Speaks only static until tuned to the
   correct frequency.
2. Keeper's journal - leather, salt-stained. The final entry reads: "The clock stopped
   at 3:47 the night Elsie went into the water. I have never let anyone wind it."
3. Locked wooden cabinet - needs a brass key.
4. Broken wall clock - hands frozen. If the player sets the hands to 3:47, the pendulum
   case springs open revealing a BRASS KEY.
5. Lighthouse control panel - dead. It has an empty fuse socket and four lamp
   switches: RED, AMBER, WHITE, GREEN.
6. Iron ceiling hatch - leads up to the Lantern Gallery. Locked until the lamp burns.

PUZZLE CHAIN (correct solutions):
- Puzzle 1 (clock): set the clock to 3:47 -> the brass key.
- Puzzle 2 (cabinet): use the brass key -> a COPPER FUSE and a TIDE CHART. On the chart
  margin: "She answers only on 1913 kHz."
- Puzzle 3 (radio): tune the radio to 1913 -> Elias's voice recites the lamp sequence
  "RED, AMBER, RED, WHITE".
- Puzzle 4 (panel): insert the copper fuse, then press RED, AMBER, RED, WHITE -> the
  lamp blazes and the iron hatch unlocks.

ROOM 2 - THE LANTERN GALLERY. Objects: the great lens, the signal bell, a salt-stained
mirror, the storm door. The mirror's condensation spells: "SPEAK THE NAME OF THE ONE I
WAIT FOR." FINAL ESCAPE: the player speaks the name "ELSIE" at the storm door ->
the door opens and the player escapes.
"""

SECRET_ANSWERS = {
    "clock_time": "3:47",
    "radio_frequency": "1913",
    "lamp_sequence": "RED, AMBER, RED, WHITE",
    "final_word": "ELSIE",
}
