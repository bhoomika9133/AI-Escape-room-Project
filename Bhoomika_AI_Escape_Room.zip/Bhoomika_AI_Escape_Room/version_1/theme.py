"""
theme.py - shared visual styling (charcoal / deep red / muted amber).

Each version keeps its own copy so that both apps run independently.
"""

import base64
from pathlib import Path

ASSETS = Path(__file__).resolve().parent / "assets"

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Special+Elite&family=IM+Fell+English:ital@0;1&display=swap');

:root {
  --bg: #0b0b0d; --panel: #141417; --panel-2: #1b1a1e; --line: #2c2a2f;
  --blood: #8a1c1c; --blood-hi: #b32a2a; --amber: #c8913f; --amber-dim: #8c6a35;
  --paper: #d9cfb8; --ink: #e6dfd0; --muted: #9a938a;
}
.stApp {
  background:
    radial-gradient(ellipse at 50% -10%, rgba(138,28,28,0.18), transparent 55%),
    radial-gradient(ellipse at 80% 110%, rgba(200,145,63,0.08), transparent 50%),
    var(--bg);
  color: var(--ink);
}
[data-testid="stSidebar"] { background: #0f0f12; border-right: 1px solid var(--line); }
h1, h2, h3, h4 { font-family: 'IM Fell English', Georgia, serif !important; color: var(--ink) !important; letter-spacing: .5px; }
p, li, label, .stMarkdown { font-family: Georgia, 'Times New Roman', serif; }

/* Title with flickering light */
.bw-title {
  font-family: 'IM Fell English', Georgia, serif; font-size: 3.1rem; text-align: center;
  color: #efe6d2; margin: .2rem 0 0 0; letter-spacing: 3px;
  text-shadow: 0 0 18px rgba(200,145,63,.35), 0 0 2px #000;
  animation: flicker 6s infinite;
}
.bw-sub { text-align:center; font-family:'Special Elite', monospace; color: var(--blood-hi);
  letter-spacing: 6px; text-transform: uppercase; font-size: .95rem; margin-bottom: 1rem; }
@keyframes flicker {
  0%, 18%, 22%, 25%, 53%, 57%, 100% { opacity: 1; }
  20%, 24%, 55% { opacity: .35; }
}
.bw-hero img { width: 100%; border: 1px solid var(--line); border-radius: 6px;
  box-shadow: 0 0 40px rgba(0,0,0,.8); animation: flicker 9s infinite; }

/* Parchment / document cards */
.bw-paper {
  background: linear-gradient(180deg, #e3d8bf, #cfc2a4); color: #2a2118;
  border-radius: 4px; padding: 1.1rem 1.3rem; font-family: 'Special Elite', monospace;
  box-shadow: inset 0 0 40px rgba(90,60,20,.35), 0 6px 18px rgba(0,0,0,.6);
  border: 1px solid #8c7a55;
}
.bw-paper p, .bw-paper li, .bw-paper strong, .bw-paper em { color: #2a2118 !important; font-family: 'Special Elite', monospace; }

.bw-panel { background: var(--panel); border: 1px solid var(--line); border-left: 3px solid var(--blood);
  border-radius: 6px; padding: .8rem 1rem; margin-bottom: .8rem; }
.bw-panel h4 { margin: 0 0 .4rem 0; font-size: 1.05rem; color: var(--amber) !important; }
.bw-chip { display:inline-block; background: var(--panel-2); border:1px solid var(--amber-dim);
  color: var(--paper); padding: 2px 9px; margin: 2px; border-radius: 12px; font-size: .82rem;
  font-family: 'Special Elite', monospace; }
.bw-chip.red { border-color: var(--blood-hi); }
.bw-muted { color: var(--muted); font-size: .85rem; }
.bw-badge { font-family:'Special Elite', monospace; font-size:.75rem; padding: 2px 8px; border-radius: 3px;
  border: 1px solid var(--line); color: var(--muted); }
.bw-badge.on { color: #9fd49a; border-color: #3f6b3c; }
.bw-badge.off { color: var(--amber); border-color: var(--amber-dim); }

/* Chat */
[data-testid="stChatMessage"] { background: rgba(20,20,23,.85); border: 1px solid var(--line);
  border-radius: 6px; }
[data-testid="stChatMessage"] p { font-size: 1.02rem; line-height: 1.55; }

/* Buttons */
.stButton > button {
  background: linear-gradient(180deg, #2a1414, #1a0d0d); color: #f0e4cc;
  border: 1px solid var(--blood); border-radius: 4px; font-family: 'Special Elite', monospace;
  letter-spacing: 1px; transition: all .2s;
}
.stButton > button:hover { border-color: var(--amber); color: #fff; box-shadow: 0 0 12px rgba(200,145,63,.35); }
.stProgress > div > div > div > div { background: linear-gradient(90deg, var(--blood), var(--amber)); }

.bw-flicker { animation: flicker 7s infinite; color: var(--amber) !important; }
.bw-end { text-align:center; padding: 2rem 1rem; }
.bw-end h1 { font-size: 2.6rem; }
</style>
"""


def svg_data_uri(name: str) -> str:
    """Return an <img>-ready data URI for an SVG asset (works on any host)."""
    data = (ASSETS / name).read_bytes()
    return "data:image/svg+xml;base64," + base64.b64encode(data).decode()


def asset_bytes(name: str) -> bytes | None:
    path = ASSETS / name
    return path.read_bytes() if path.exists() else None
