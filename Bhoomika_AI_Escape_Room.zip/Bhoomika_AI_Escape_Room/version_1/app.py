"""
Version 1 - app.py
==================
THE BLACKWOOD LIGHTHOUSE: THE KEEPER'S LAST SHIFT - Interactive AI Horror Escape Room

Run:  streamlit run version_1/app.py

Version 1 is a conversation-driven game: every player message is added to a
chat history and sent to the Gemini Game Master, which decides what happens.
The only state kept is the conversation itself and the item/escape tags the
model chooses to emit (see game_master.py).
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import streamlit as st

# Make sibling modules importable whatever the working directory is.
sys.path.insert(0, str(Path(__file__).resolve().parent))

from game_data import GAME_SUBTITLE, GAME_TITLE, INSTRUCTIONS, INTRO_TEXT, ROOM_OBJECTS  # noqa: E402
from game_master import GeminiGameMaster, OfflineGameMaster  # noqa: E402
from theme import CSS, asset_bytes, svg_data_uri  # noqa: E402

st.set_page_config(page_title="Blackwood Lighthouse - V1", page_icon="🕯️", layout="wide")
st.markdown(CSS, unsafe_allow_html=True)


# --------------------------------------------------------------------------
# API key: environment variable / .env file / Streamlit secrets. Never hardcoded.
# --------------------------------------------------------------------------
def load_api_key() -> str | None:
    try:
        from dotenv import load_dotenv

        load_dotenv(Path(__file__).resolve().parent.parent / ".env")
    except ImportError:
        pass
    key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    if not key:
        try:
            key = st.secrets.get("GEMINI_API_KEY")  # .streamlit/secrets.toml
        except Exception:
            key = None
    return key


def init_state() -> None:
    defaults = {
        "screen": "home",      # home -> intro -> play -> escaped
        "history": [],         # [{"role": "user"/"assistant", "content": str}]
        "gm_items": [],         # items the Game Master SAYS the player has
        "gm_source": None,
    }
    for k, v in defaults.items():
        st.session_state.setdefault(k, v)
    if "gm" not in st.session_state:
        gm = GeminiGameMaster(load_api_key())
        st.session_state.gm = gm if gm.available else None
        st.session_state.offline = OfflineGameMaster()


def restart() -> None:
    for k in ("screen", "history", "gm_items", "gm_source"):
        st.session_state.pop(k, None)
    init_state()


def ask_game_master(text: str) -> None:
    """Send the player's text to the Game Master and store the reply."""
    history = st.session_state.history
    reply = None
    if st.session_state.gm is not None:
        try:
            reply = st.session_state.gm.respond(history, text)
        except Exception as exc:
            st.toast(f"Gemini unavailable, using offline Game Master ({str(exc)[:80]})")
    if reply is None:
        reply = st.session_state.offline.respond(history, text)
        reply.source = "offline"
    st.session_state.gm_source = reply.source
    history.append({"role": "user", "content": text})
    history.append({"role": "assistant", "content": reply.text})
    for item in reply.items:                      # trusted blindly (V1 limitation)
        if item not in st.session_state.gm_items:
            st.session_state.gm_items.append(item)
    if reply.escaped:                             # trusted blindly (V1 limitation)
        st.session_state.screen = "escaped"


# --------------------------------------------------------------------------
# Screens
# --------------------------------------------------------------------------
def header() -> None:
    st.markdown(f"<div class='bw-title'>{GAME_TITLE}</div>", unsafe_allow_html=True)
    st.markdown(f"<div class='bw-sub'>{GAME_SUBTITLE}</div>", unsafe_allow_html=True)


def home_screen() -> None:
    header()
    _, mid, _ = st.columns([1, 3, 1])
    with mid:
        st.markdown(f"<div class='bw-hero'><img src='{svg_data_uri('lighthouse.svg')}'/></div>",
                    unsafe_allow_html=True)
        st.markdown("<p style='text-align:center;margin-top:1rem'>A supernatural "
                    "psychological horror escape room, run by an AI Game Master.</p>",
                    unsafe_allow_html=True)
        st.markdown("<p class='bw-muted' style='text-align:center'>Version 1: "
                    "conversation-driven prototype</p>", unsafe_allow_html=True)
        if st.button("ENTER THE LIGHTHOUSE", use_container_width=True):
            st.session_state.screen = "intro"
            st.rerun()


def intro_screen() -> None:
    header()
    left, right = st.columns([3, 2])
    with left:
        st.markdown(f"<div class='bw-paper'>{_md(INTRO_TEXT)}</div>", unsafe_allow_html=True)
    with right:
        st.markdown(f"<div class='bw-panel'>{_md(INSTRUCTIONS)}</div>", unsafe_allow_html=True)
        bell = asset_bytes("bell.wav")
        if bell:
            st.caption("The bell (play with sound on):")
            st.audio(bell, format="audio/wav")
        if st.button("START GAME", use_container_width=True):
            st.session_state.screen = "play"
            st.session_state.history.append({
                "role": "assistant",
                "content": "You stand in the Watch Room. Rain hammers the single window. "
                           "A radio crackles on the desk beside a leather journal; a wooden "
                           "cabinet, a stopped wall clock and a dead control panel line the "
                           "walls. Above you, an iron hatch. What do you do?",
            })
            st.rerun()


def play_screen() -> None:
    with st.sidebar:
        st.markdown("### The Watch Room")
        st.markdown("".join(f"<span class='bw-chip'>{o}</span>" for o in ROOM_OBJECTS),
                    unsafe_allow_html=True)
        st.markdown("<div class='bw-panel'><h4>Items (as told by the Game Master)</h4>" +
                    ("".join(f"<span class='bw-chip red'>{i}</span>" for i in st.session_state.gm_items)
                     or "<span class='bw-muted'>Nothing yet.</span>") + "</div>",
                    unsafe_allow_html=True)
        src = st.session_state.gm_source or ("gemini" if st.session_state.gm else "offline")
        cls = "on" if src == "gemini" else "off"
        label = "Gemini Game Master" if src == "gemini" else "Offline Game Master"
        st.markdown(f"<span class='bw-badge {cls}'>{label}</span>", unsafe_allow_html=True)
        st.caption("V1 keeps no structured state. Progress lives only in the conversation.")
        if st.button("Restart"):
            restart()
            st.rerun()

    header()
    for turn in st.session_state.history:
        with st.chat_message("user" if turn["role"] == "user" else "assistant",
                             avatar="🧍" if turn["role"] == "user" else "🕯️"):
            st.markdown(turn["content"])

    text = st.chat_input("What do you do?")
    if text:
        ask_game_master(text.strip())
        st.rerun()


def escaped_screen() -> None:
    header()
    st.markdown("<div class='bw-end'><h1>YOU ESCAPED</h1><p>The storm door opens onto a grey "
                "dawn. Behind you the lamp burns steady. For the first time in over a "
                "century, the keeper's shift is over.</p></div>", unsafe_allow_html=True)
    st.balloons()
    st.caption(f"Messages exchanged: {len(st.session_state.history)}")
    if st.button("PLAY AGAIN", use_container_width=True):
        restart()
        st.rerun()


def _md(text: str) -> str:
    """Tiny markdown-to-HTML helper for text placed inside styled <div>s."""
    import markdown

    return markdown.markdown(text)


init_state()
{"home": home_screen, "intro": intro_screen, "play": play_screen,
 "escaped": escaped_screen}[st.session_state.screen]()
