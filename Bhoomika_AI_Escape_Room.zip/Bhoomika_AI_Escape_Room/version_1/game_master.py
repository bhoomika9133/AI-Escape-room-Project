"""
Version 1 - game_master.py
==========================
The AI Game Master for Version 1.

Architecture (intentionally simple, and intentionally fragile):

    player text --> conversation history --> Gemini (with full rules + answers)
                                                 |
                       narrative text + optional tags [ITEM: x] / [ESCAPED]
                                                 |
                       the UI shows the text and trusts the tags

* Gemini decides EVERYTHING: what is found, whether puzzles are solved and
  whether the player escapes.
* The only "state" is the chat transcript plus whatever tags the model emits.
* If Gemini is unavailable (no key / no network / quota), an OfflineGameMaster
  keeps the game playable. It is a keyword matcher with NO memory of what has
  been done, which mirrors V1's lack of authoritative state.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field

from game_data import WORLD_RULES

# Models tried in order. GEMINI_MODEL (env) wins if set. "gemini-flash-latest"
# is Google's rolling alias for the current free-tier Flash model.
DEFAULT_MODELS = ["gemini-flash-latest", "gemini-2.5-flash", "gemini-2.5-flash-lite"]

ITEM_TAG = re.compile(r"\[ITEM:\s*([^\]]+)\]", re.IGNORECASE)
ESCAPE_TAG = re.compile(r"\[ESCAPED\]", re.IGNORECASE)


def build_system_prompt() -> str:
    """The single prompt that defines the entire Version 1 game."""
    return f"""You are the Game Master of a supernatural psychological horror escape room.
Narrate in second person, present tense, 60-140 words, cinematic and unsettling but
never gory. Describe sounds, light, cold and the storm. Respond to whatever the player
types in natural language.

{WORLD_RULES}

GAME MASTER RULES:
- Keep the solutions secret. Give only gentle hints if the player is stuck.
- Do not let the player skip puzzles or use items they have not found.
- When the player obtains an item, append a tag on its own line: [ITEM: Item Name]
- Only when the player completes the final escape, append: [ESCAPED]
"""


@dataclass
class GMReply:
    """What the Game Master returns to the UI."""
    text: str
    items: list[str] = field(default_factory=list)
    escaped: bool = False
    source: str = "offline"  # "gemini" or "offline"


def parse_tags(raw: str) -> GMReply:
    """Pull [ITEM: x] and [ESCAPED] tags out of the model text.

    NOTE: Version 1 trusts these tags blindly - if the model (or a manipulated
    model) emits [ESCAPED], the UI shows the success screen.
    """
    items = [m.strip() for m in ITEM_TAG.findall(raw)]
    escaped = bool(ESCAPE_TAG.search(raw))
    clean = ESCAPE_TAG.sub("", ITEM_TAG.sub("", raw)).strip()
    return GMReply(text=clean, items=items, escaped=escaped)


# ---------------------------------------------------------------------------
# Gemini Game Master
# ---------------------------------------------------------------------------
class GeminiGameMaster:
    """Sends the full conversation to Gemini every turn."""

    def __init__(self, api_key: str | None = None):
        self.api_key = api_key or os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        self.client = None
        self.model = None
        self.last_error: str | None = None
        if self.api_key:
            try:
                from google import genai  # imported lazily so offline mode needs no SDK

                self.client = genai.Client(api_key=self.api_key)
            except Exception as exc:  # pragma: no cover - depends on environment
                self.last_error = f"Gemini SDK unavailable: {exc}"

    @property
    def available(self) -> bool:
        return self.client is not None

    def _models(self) -> list[str]:
        env = os.getenv("GEMINI_MODEL")
        return ([env] if env else []) + [m for m in DEFAULT_MODELS if m != env]

    def respond(self, history: list[dict], player_text: str) -> GMReply:
        """history: list of {"role": "user"|"assistant", "content": str}."""
        from google.genai import types

        contents = []
        for turn in history[-30:]:  # memory: the last 30 turns are resent each time
            role = "user" if turn["role"] == "user" else "model"
            contents.append(types.Content(role=role, parts=[types.Part(text=turn["content"])]))
        contents.append(types.Content(role="user", parts=[types.Part(text=player_text)]))

        config = types.GenerateContentConfig(
            system_instruction=build_system_prompt(), temperature=0.9, max_output_tokens=400
        )
        for model in ([self.model] if self.model else self._models()):
            try:
                resp = self.client.models.generate_content(
                    model=model, contents=contents, config=config
                )
                self.model = model
                reply = parse_tags(resp.text or "")
                reply.source = "gemini"
                return reply
            except Exception as exc:  # try the next model name
                self.last_error = str(exc)
        raise RuntimeError(self.last_error or "Gemini call failed")


# ---------------------------------------------------------------------------
# Offline fallback (keyword matcher, stateless by design)
# ---------------------------------------------------------------------------
class OfflineGameMaster:
    """Keeps Version 1 playable without Gemini.

    It looks only at the CURRENT sentence. It has no inventory and no record of
    solved puzzles, so it cannot enforce prerequisites. This is the same class
    of weakness as an LLM-only game master and is demonstrated in the tests.
    """

    def respond(self, history: list[dict], player_text: str) -> GMReply:
        raw = self._keyword_reply(player_text)
        reply = parse_tags(raw.text)          # same tag handling as the Gemini path
        reply.escaped = reply.escaped or raw.escaped
        reply.source = "offline"
        return reply

    def _keyword_reply(self, player_text: str) -> GMReply:
        t = player_text.lower()
        has = lambda *words: any(w in t for w in words)  # noqa: E731

        if has("hint", "stuck", "help me"):
            return GMReply("A cold draught turns the journal's pages for you. "
                           "Perhaps the keeper wrote down what he could not forget.")
        if has("elsie"):
            return GMReply("You whisper the name. The storm falls silent. Behind you, a small "
                           "wet hand slips into yours, and the storm door swings open onto "
                           "grey dawn. You are outside. You are free.", escaped=True)
        if has("journal", "diary", "book"):
            return GMReply("The journal's last entry is written in shaking ink: *\"The clock "
                           "stopped at 3:47 the night Elsie went into the water. I have never "
                           "let anyone wind it.\"* Below it, the same sigil is drawn over and "
                           "over, pressed so hard the pen tore the page.")
        if has("clock"):
            if has("3:47", "347", "3.47", "three forty"):
                return GMReply("You drag the hands to 3:47. Something inside the clock "
                               "exhales. The pendulum case clicks open, and on a bed of "
                               "dried seaweed lies a small brass key.\n[ITEM: Brass Key]")
            return GMReply("The wall clock's glass is cracked in a spider-web pattern. Its "
                           "hands hang loose, and you could move them. The pendulum case "
                           "is shut tight.")
        if has("cabinet", "cupboard"):
            if has("open", "unlock", "key", "use"):
                return GMReply("The lock turns with a groan. Inside: a copper fuse wrapped in "
                               "oilcloth, and a tide chart. In the margin someone has "
                               "written: *\"She answers only on 1913 kHz.\"*\n"
                               "[ITEM: Copper Fuse]\n[ITEM: Tide Chart]")
            return GMReply("A heavy oak cabinet with a brass keyhole. Something inside "
                           "shifts when the wind hits the tower.")
        if has("radio", "receiver"):
            if has("1913"):
                return GMReply("The static parts like a curtain. Elias Crane's voice, very "
                               "close: *\"Light her home. Red... amber... red... white. "
                               "Don't let it go dark again.\"*")
            return GMReply("The radio hisses. Under the static, someone is breathing in time "
                           "with you. The tuning dial is marked in kHz.")
        if has("panel", "switch", "lamp", "control"):
            if all(c in t for c in ("red", "amber", "white")):
                return GMReply("Relays thunder. Far above, the great lamp ignites and the "
                               "tower floods with gold. With a shriek of rust, the iron "
                               "hatch in the ceiling unlocks.")
            return GMReply("A dead control panel: an empty fuse socket and four lamp "
                           "switches marked RED, AMBER, WHITE and GREEN.")
        if has("hatch", "climb", "upstairs", "go up"):
            return GMReply("You climb into the Lantern Gallery. The great lens turns slowly "
                           "with no motor to drive it. A salt-stained mirror faces the "
                           "storm door, and the signal bell hangs silent... for now.")
        if has("mirror"):
            return GMReply("Your breath fogs the mirror, and letters form from the inside: "
                           "*SPEAK THE NAME OF THE ONE I WAIT FOR.*")
        if has("door", "escape", "leave"):
            return GMReply("The storm door is sealed with something that is not a lock. It "
                           "is waiting for a word.")
        return GMReply("The wind screams through the gallery rails above. Nothing answers "
                       "you except the slow tick of a clock that should not be ticking.")


def get_game_master():
    """Return a Gemini game master if a key is configured, else the offline one."""
    gm = GeminiGameMaster()
    return gm if gm.available else OfflineGameMaster()
